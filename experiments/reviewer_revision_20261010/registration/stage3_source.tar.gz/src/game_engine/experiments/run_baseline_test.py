"""
experiments/run_baseline_test.py

Purpose:
- End-to-end sanity test of env with one LLM agent vs one baseline agent.
- Writes logs using the same directory logic as the cross-play runner.
"""

from __future__ import annotations

from game_engine.experiments.settings import ROUNDS, HISTORY_ROUNDS, STATS_ROUNDS, DRIFT_WINDOW

import os

from game_engine.agents import RandomAgent
from game_engine.agents.llm_wrapper import LLMWrapperAgent
from game_engine.env.simulator import GameSimulator
from game_engine.env.types import (
    DriftConfig,
    EnvConfig,
    ObservationConfig,
    PayoffConfig,
    StreakConfig,
)
from game_engine.io.jsonl import write_episode
from game_engine.io.run_paths import build_experiment_id, ensure_dir, write_json


def main() -> None:
    cfg = EnvConfig(
        N=2,
        M=2,
        T=ROUNDS,
        p_perception=0.10,
        payoff=PayoffConfig(
            B0=2.0,
            C=1.0,
            K=0.0,
            B_min=1.2,
            B_max=3.0,
        ),
        drift=DriftConfig(
            window_w=DRIFT_WINDOW,
            eta=0.05,
            r_star=0.5,
        ),
        streak=StreakConfig(
            theta=0,
            lam=0.3,
            tau=5.0,
        ),
        obs=ObservationConfig(history_k=HISTORY_ROUNDS, stats_window=STATS_ROUNDS),
        seed=123,
    )

    assert (
        cfg.payoff.B_min * (1.0 + cfg.streak.lam) > cfg.payoff.C
    ), "PD constraint violated: B_eff may drop <= C"

    run_id = build_experiment_id(
        "baseline",
        cfg=cfg,
        num_seeds=1,
        extra_tags=["llama31_8b_vs_random"],
    )
    run_dir = ensure_dir(os.path.join("results", "baseline", run_id))
    match_dir = ensure_dir(os.path.join(run_dir, "single_match"))

    write_json(
        os.path.join(run_dir, "manifest.json"),
        {
            "run_id": run_id,
            "experiment_type": "baseline",
            "config": cfg,
        },
    )

    agents = [
        LLMWrapperAgent(
            name="llama31_8b",
            agent_id=0,
            env_cfg=cfg,
            backend="openrouter",
            model_name="meta-llama/llama-3.1-8b-instruct",
            prompt_dir="AI_Agent/prompts",
            output_dir=os.path.join(match_dir, "agents", "p0__llama31_8b"),
        ),
        RandomAgent("rand1"),
    ]

    write_json(
        os.path.join(match_dir, "match_manifest.json"),
        {
            "run_id": run_id,
            "match_id": "single_match",
            "config": cfg,
            "agents": [
                "meta-llama/llama-3.1-8b-instruct",
                "RandomAgent",
            ],
        },
    )

    sim = GameSimulator(cfg)
    result = sim.run_episode(agents)

    meta_path, logs_path = write_episode(
        match_dir,
        run_id,
        0,
        result,
        extra_meta={"match_id": "single_match"},
        stem="episode_000",
    )

    print("Wrote:", meta_path)
    print("Wrote:", logs_path)
    print("Total rewards:", result.total_rewards)
    print("Final B:", result.final_B, "Final streak:", result.final_streak)
    print("Run dir:", run_dir)


if __name__ == "__main__":
    main()